# Pharmacy Management System — Starter

An original, English-language pharmacy management web-app starter. It is inspired by common pharmacy workflows, not copied from Candela's proprietary software.

## Features included in this starter
- Dashboard with today's sales, stock count, low-stock and near-expiry lists
- Medicine catalogue with SKU, generic name, manufacturer, batch, expiry, purchase/sale prices and stock
- Simple one-medicine-per-invoice sales; stock decreases automatically
- Purchase entry; stock increases automatically
- Basic sales, purchases, expenses and stock valuation reports
- SQLite database for local development
- Responsive layout suitable for a phone or desktop browser

## Run locally
Requires Python 3.10+.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000

## Android-only development using a cloud workspace
1. Create a new GitHub repository for your project.
2. Upload these project files to that repository (extract the ZIP first).
3. Create a GitHub Codespace for your own repository.
4. In the Codespaces terminal, run:
   ```bash
   pip install -r requirements.txt
   python app.py
   ```
5. Use the forwarded port 5000 link provided by Codespaces to preview the app.

## Important limitations — not production-ready
This is a starter prototype, not a validated pharmacy system. It has no login/role permissions, audit log, barcode integration, multi-line invoices, tax configuration, prescription workflow, controlled-drug compliance, supplier/customer ledgers, returns, backup automation, or production deployment hardening. Demo medicines are seeded for testing; remove them before real use. Do not enter real patient data or rely on it for dispensing until security, legal compliance, backups and calculations have been professionally reviewed. Use a proper production secret, secure database, HTTPS, authorization, and audit logging before deployment.

## Where REA fits
REA is a separate reverse-engineering/developer tool; it is not a runtime dependency of this app. Use REA only with software you own or have permission to analyze. This pharmacy app is an original implementation of common workflows.
