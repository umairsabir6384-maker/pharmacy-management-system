from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from pathlib import Path
from datetime import datetime

APP_DIR = Path(__file__).resolve().parent
DB_PATH = APP_DIR / "pharmacy.db"
app = Flask(__name__)
app.secret_key = "change-this-before-deployment"

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS medicines (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sku TEXT UNIQUE,
            name TEXT NOT NULL,
            generic_name TEXT DEFAULT '',
            manufacturer TEXT DEFAULT '',
            batch_no TEXT DEFAULT '',
            expiry_date TEXT DEFAULT '',
            purchase_price REAL NOT NULL DEFAULT 0,
            sale_price REAL NOT NULL DEFAULT 0,
            stock_units INTEGER NOT NULL DEFAULT 0,
            reorder_level INTEGER NOT NULL DEFAULT 10,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS sales (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            invoice_no TEXT NOT NULL UNIQUE,
            customer_name TEXT DEFAULT '',
            total REAL NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS sale_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sale_id INTEGER NOT NULL REFERENCES sales(id),
            medicine_id INTEGER NOT NULL REFERENCES medicines(id),
            quantity INTEGER NOT NULL,
            unit_price REAL NOT NULL,
            line_total REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS purchases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            supplier_name TEXT NOT NULL,
            invoice_ref TEXT DEFAULT '',
            total REAL NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS purchase_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            purchase_id INTEGER NOT NULL REFERENCES purchases(id),
            medicine_id INTEGER NOT NULL REFERENCES medicines(id),
            quantity INTEGER NOT NULL,
            unit_cost REAL NOT NULL,
            line_total REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            description TEXT NOT NULL,
            amount REAL NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        """)
        count = con.execute("SELECT COUNT(*) FROM medicines").fetchone()[0]
        if count == 0:
            con.executemany("""INSERT INTO medicines
              (sku,name,generic_name,manufacturer,batch_no,expiry_date,purchase_price,sale_price,stock_units,reorder_level)
              VALUES (?,?,?,?,?,?,?,?,?,?)""", [
                ("DEMO-001","Paracetamol 500mg","Paracetamol","Demo Pharma","B-DEMO-01","2027-12-31",2.0,3.0,100,20),
                ("DEMO-002","Cetirizine 10mg","Cetirizine","Demo Pharma","B-DEMO-02","2027-08-31",4.0,6.0,8,15),
            ])

@app.route("/")
def dashboard():
    with db() as con:
        stats = {
            "medicines": con.execute("SELECT COUNT(*) FROM medicines").fetchone()[0],
            "stock_units": con.execute("SELECT COALESCE(SUM(stock_units),0) FROM medicines").fetchone()[0],
            "low_stock": con.execute("SELECT COUNT(*) FROM medicines WHERE stock_units <= reorder_level").fetchone()[0],
            "today_sales": con.execute("SELECT COALESCE(SUM(total),0) FROM sales WHERE date(created_at)=date('now','localtime')").fetchone()[0],
        }
        expiring = con.execute("""SELECT * FROM medicines WHERE expiry_date <> ''
          AND date(expiry_date) <= date('now','+90 days') ORDER BY expiry_date LIMIT 8""").fetchall()
        low = con.execute("SELECT * FROM medicines WHERE stock_units <= reorder_level ORDER BY stock_units LIMIT 8").fetchall()
    return render_template("dashboard.html", stats=stats, expiring=expiring, low=low)

@app.route("/medicines", methods=["GET","POST"])
def medicines():
    if request.method == "POST":
        f = request.form
        try:
            with db() as con:
                con.execute("""INSERT INTO medicines
                (sku,name,generic_name,manufacturer,batch_no,expiry_date,purchase_price,sale_price,stock_units,reorder_level)
                VALUES (?,?,?,?,?,?,?,?,?,?)""",
                (f.get("sku","").strip() or None, f["name"].strip(), f.get("generic_name","").strip(),
                 f.get("manufacturer","").strip(), f.get("batch_no","").strip(), f.get("expiry_date",""),
                 float(f.get("purchase_price") or 0), float(f.get("sale_price") or 0),
                 int(f.get("stock_units") or 0), int(f.get("reorder_level") or 10)))
            flash("Medicine added.", "success")
        except sqlite3.IntegrityError:
            flash("That SKU already exists. Use a unique SKU.", "error")
        except (ValueError, KeyError):
            flash("Please check the form values.", "error")
        return redirect(url_for("medicines"))
    q = request.args.get("q","").strip()
    with db() as con:
        rows = con.execute("""SELECT * FROM medicines WHERE name LIKE ? OR generic_name LIKE ? OR sku LIKE ?
          ORDER BY name""", (f"%{q}%",f"%{q}%",f"%{q}%")).fetchall()
    return render_template("medicines.html", medicines=rows, q=q)

@app.route("/sales", methods=["GET","POST"])
def sales():
    if request.method == "POST":
        try:
            med_id = int(request.form["medicine_id"])
            qty = int(request.form["quantity"])
            customer = request.form.get("customer_name","").strip()
            if qty <= 0: raise ValueError()
            with db() as con:
                med = con.execute("SELECT * FROM medicines WHERE id=?", (med_id,)).fetchone()
                if not med: raise ValueError()
                if med["stock_units"] < qty:
                    flash("Not enough stock for this sale.", "error")
                    return redirect(url_for("sales"))
                total = round(med["sale_price"] * qty, 2)
                invoice = "INV-" + datetime.now().strftime("%Y%m%d-%H%M%S-%f")
                cur = con.execute("INSERT INTO sales(invoice_no,customer_name,total) VALUES (?,?,?)", (invoice,customer,total))
                con.execute("INSERT INTO sale_items(sale_id,medicine_id,quantity,unit_price,line_total) VALUES (?,?,?,?,?)",
                            (cur.lastrowid,med_id,qty,med["sale_price"],total))
                con.execute("UPDATE medicines SET stock_units=stock_units-? WHERE id=?", (qty,med_id))
            flash(f"Sale saved: {invoice} — Rs {total:.2f}", "success")
        except (ValueError, KeyError):
            flash("Please select a medicine and enter a valid quantity.", "error")
        return redirect(url_for("sales"))
    with db() as con:
        meds = con.execute("SELECT * FROM medicines WHERE stock_units > 0 ORDER BY name").fetchall()
        rows = con.execute("""SELECT s.*, m.name AS medicine_name, si.quantity FROM sales s
            JOIN sale_items si ON si.sale_id=s.id JOIN medicines m ON m.id=si.medicine_id
            ORDER BY s.id DESC LIMIT 30""").fetchall()
    return render_template("sales.html", medicines=meds, sales=rows)

@app.route("/purchases", methods=["GET","POST"])
def purchases():
    if request.method == "POST":
        try:
            med_id=int(request.form["medicine_id"]); qty=int(request.form["quantity"])
            cost=float(request.form["unit_cost"]); supplier=request.form["supplier_name"].strip()
            ref=request.form.get("invoice_ref","").strip()
            if qty <= 0 or cost < 0 or not supplier: raise ValueError()
            total=round(qty*cost,2)
            with db() as con:
                med=con.execute("SELECT id FROM medicines WHERE id=?",(med_id,)).fetchone()
                if not med: raise ValueError()
                cur=con.execute("INSERT INTO purchases(supplier_name,invoice_ref,total) VALUES (?,?,?)",(supplier,ref,total))
                con.execute("INSERT INTO purchase_items(purchase_id,medicine_id,quantity,unit_cost,line_total) VALUES (?,?,?,?,?)",
                            (cur.lastrowid,med_id,qty,cost,total))
                con.execute("UPDATE medicines SET stock_units=stock_units+?, purchase_price=? WHERE id=?",(qty,cost,med_id))
            flash("Purchase recorded and stock updated.", "success")
        except (ValueError, KeyError):
            flash("Please complete the purchase fields correctly.", "error")
        return redirect(url_for("purchases"))
    with db() as con:
        meds=con.execute("SELECT * FROM medicines ORDER BY name").fetchall()
        rows=con.execute("""SELECT p.*,m.name AS medicine_name,pi.quantity,pi.unit_cost
          FROM purchases p JOIN purchase_items pi ON pi.purchase_id=p.id
          JOIN medicines m ON m.id=pi.medicine_id ORDER BY p.id DESC LIMIT 30""").fetchall()
    return render_template("purchases.html", medicines=meds, purchases=rows)

@app.route("/reports")
def reports():
    with db() as con:
        sales=con.execute("""SELECT date(created_at) day, COUNT(*) invoices, SUM(total) total
          FROM sales GROUP BY date(created_at) ORDER BY day DESC LIMIT 30""").fetchall()
        stock_value=con.execute("SELECT COALESCE(SUM(stock_units*purchase_price),0) FROM medicines").fetchone()[0]
        sales_total=con.execute("SELECT COALESCE(SUM(total),0) FROM sales").fetchone()[0]
        purchase_total=con.execute("SELECT COALESCE(SUM(total),0) FROM purchases").fetchone()[0]
        expenses_total=con.execute("SELECT COALESCE(SUM(amount),0) FROM expenses").fetchone()[0]
    return render_template("reports.html", sales=sales, stock_value=stock_value, sales_total=sales_total,
                           purchase_total=purchase_total, expenses_total=expenses_total)

@app.route("/expenses", methods=["GET","POST"])
def expenses():
    if request.method == "POST":
        try:
            description=request.form["description"].strip(); amount=float(request.form["amount"])
            if not description or amount < 0: raise ValueError()
            with db() as con:
                con.execute("INSERT INTO expenses(description,amount) VALUES (?,?)",(description,amount))
            flash("Expense recorded.", "success")
        except (ValueError, KeyError):
            flash("Enter a description and valid amount.", "error")
        return redirect(url_for("expenses"))
    with db() as con:
        rows=con.execute("SELECT * FROM expenses ORDER BY id DESC LIMIT 100").fetchall()
    return render_template("expenses.html", expenses=rows)

@app.route("/health")
def health():
    return {"status":"ok","application":"Pharmacy Management Starter"}

init_db()
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
